<?php
// header("Access-Control-Allow-Origin: *");
 $con=mysqli_connect("localhost","USERNAME DATABASE ANDA","PASSWORD DATABASE ANDA","latihan_crud");

//menentukan timezone
date_default_timezone_set('Asia/Makassar');
?>
