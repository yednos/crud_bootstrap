<!-- 
=============================================================================
+                          SIMPLE CRUD                                      +
+                                                                           +
+                  Dibuat oleh YOHYEDNOS NAKO                               +
+                        www.coneons.com                                    +
+         Dapatkan berbagai source code gratis di website kami.             +
+                Kami juga melayani pembuatan aplikasi                      +
+        silahkan kontak kami lewat email kami yednos@gmail.com             +
+                                                                           +
+                                                                           +
+                                                                           +
+                        WWW.CONEONS.COM                                    +
+                                                                           +
+   Hargai pembuat aplikasi dengan tidak menghapus nama pembuat di footer   +
=============================================================================
-->

<?php
include "config/koneksi.php";
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>SIMPLE CRUD | www.coneons.com</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
    <script src="js/jquery311.js" crossorigin="anonymous"></script>
    <script src="js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
  
    <!-- data tables style-->
  <link rel="stylesheet" type="text/css" href="css/jquery.dataTables.css">
  <style type="text/css" class="init">
  
  div.dataTables_wrapper {
    width: 100%;
    margin: 0 auto;
  }
  /* Change the link color on hover */
  li a:hover {
      background-color: silver;
      color: #ffffff;
  }
  </style>
  <script type="text/javascript" language="javascript" src="js/jquery-1.12.4.js">
  </script>
  <script type="text/javascript" language="javascript" src="js/jquery.dataTables.js">
  </script>
  <script type="text/javascript" language="javascript" src="js/shCore.js">
  </script>
  <script type="text/javascript" language="javascript" src="js/demo.js">
  </script>
  <script type="text/javascript" language="javascript" class="init">
  $(document).ready(function() {
    $('#tabel').DataTable( {
      "scrollY": 400,
      "scrollY": true
    } );
  } );
  </script>
  <!-- end data tables style-->

    <!-- custom css -->
    <link href='css/yed-custom.css' rel='stylesheet' />

    <!-- untuk font icon -->
    <link href="css/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <!-- end font icon -->
    
  </head>
  <body style="background-image:url('img/ok.jpg');background-size:100%;background-repeat:no-repeat;background-attachment: fixed;">
    <span class='nprogress-logo fade out'></span>

<nav class="navbar navbar-toggleable-md navbar-light bg-faded fixed-top border borderbottom">
  <div class="container">
      
            <div class="navbar-header">
                <a class="navbar-brand" href=".">
                  <span class="glyphicon glyphicon-fire"></span> 
                  <b>SIMPLE CRUD</b>
                </a>
                <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#collapsingNavbar" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                </button>
            </div>
            

            <div class="collapse navbar-collapse" id="collapsingNavbar">
            
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="." aria-haspopup="true" aria-expanded="false">
                    Beranda
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="?pages=kecamatan" aria-haspopup="true" aria-expanded="false">Kecamatan</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="?pages=desa" aria-haspopup="true" aria-expanded="false">Desa</a>
                </li>
            </ul>            
        </div>
    </div>
</nav>

    <!-- Content -->
  
      <?php
      $mods_dir = 'modul';
      if(!empty($_GET['pages'])){
        $pages = scandir($mods_dir, 0);
        unset($pages[0], $pages[1]);
 
        $p = $_GET['pages'];
        if(in_array($p.'.php', $pages)){
          include($mods_dir.'/'.$p.'.php');
        } else {
          echo '<center>Halaman tidak ditemukan! :(</center>';
        }
      } else {
        include($mods_dir.'/home.php');
      }
      ?>
    <!-- /.end content -->
  
  <div class="clearfix"><br /><br /></div>
  <footer><hr />
        <div class="small-print">
          <div class="container">
            <p>Developed by <a href="http://www.coneons.com" target="_blank">www.coneons.com</a> | <?php echo date('Y'); ?> </p>
          </div>
        </div>
  </footer>    

  </body>
</html>