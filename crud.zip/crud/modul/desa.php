<!-- 
=============================================================================
+                          SIMPLE CRUD                                      +
+                                                                           +
+                  Dibuat oleh YOHYEDNOS NAKO                               +
+                        www.coneons.com                                    +
+         Dapatkan berbagai source code gratis di website kami.             +
+                Kami juga melayani pembuatan aplikasi                      +
+        silahkan kontak kami lewat email kami yednos@gmail.com             +
+                                                                           +
+                                                                           +
+                                                                           +
+                        WWW.CONEONS.COM                                    +
+                                                                           +
+   Hargai pembuat aplikasi dengan tidak menghapus nama pembuat di footer   +
=============================================================================
-->
<!-- Container -->
<div class="container" style="padding-top: 70px;min-height: 600px;">

  
  <div class="card">
    <div class="card-header">
      <h5>DESA</h5>
    </div>
    <div class="card-block">
      <a href="#tambahdata" id="custId" data-toggle="modal">
        <button type="button" class="btn btn-primary fa fa-plus">TAMBAH DATA</button>
      </a>
      <!-- <button type="button" class="btn btn-warning fa fa-undo">CETAK LAPORAN</button> -->
      <p>&nbsp;</p>
      
      <table id="tabel" class="display nowrap" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th align="center" width="60px;">#</th>
                <th width="10px;">No</th>
                <th>Nama desa</th>
                <th>Nama kepala desa</th>
                <th>Ibukota</th>
                <th>Kecamatan</th>
            </tr>
        </thead>
        
        <tbody>
        <?php
        $no = 0;
        $modal=mysqli_query($con, "SELECT * FROM desa,kecamatan
                            WHERE kecamatan.id_kecamatan=desa.id_kecamatan
                            ORDER BY desa.nama_desa ASC");
        while($r=mysqli_fetch_array($modal)){
          $no++;
          ?>
            <tr>
                <td align="center">
                  <a href="#editdata" id="custId" data-toggle="modal" data-id="<?php echo "$r[id_desa]"; ?>"><img src="icon/edit.png"></a>
                  &nbsp;
                  <a href="#hapusdata" id="custId" data-toggle="modal" data-id="<?php echo "$r[id_desa]"; ?>"><img src="icon/delete.png"></a>
                </td>
                <td><?php echo $no; ?></td>
                <td><?php echo $r['nama_desa']; ?></td>
                <td><?php echo $r['kepala_desa']; ?></td>
                <td><?php echo $r['ibukota_desa']; ?></td>
                <td><?php echo $r['nama_kecamatan']; ?></td>
            </tr>
        <?php
        }
        ?>
        </tbody>
      </table>
      
    </div>
  </div>


</div>
<!-- End container -->


<!-- ============================================ Modal tambah data ====================================== -->
<div class="modal fade" id="tambahdata" role="dialog">
        <div class="modal-dialog modal-lg" role="document">
            
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">TAMBAH DATA</h4>
                    <button type="button" class="close" data-dismiss="modal" onclick="document.location.reload();">&times;</button>
                </div>
                <div class="modal-body">
                    Kecamatan
                    <select name="kecamatan" class="form-control" id="kecamatan" required>
                      <option value="" selected>[pilih kecamatan]</option>
                      <?php
                      $qt = mysqli_query($con, "SELECT * FROM kecamatan ORDER BY nama_kecamatan ASC");
                      while($r=mysqli_fetch_array($qt)){
                        echo "<option value='$r[id_kecamatan]'>$r[nama_kecamatan]</option>";
                      }
                      ?>
                    </select>
                    Nama desa
                    <input type="text" name="nama" id="nama" required class="form-control" autofocus="true">
                    Kepala desa
                    <input type="text" name="kepaladesa" id="kepaladesa" required class="form-control">
                    Ibukota
                    <input type="text" name="ibukota" id="ibukota" required class="form-control" value="">
                    Bendahara
                    <input type="text" name="bendahara" id="bendahara" required class="form-control" value="">
                </div>
                <div class="modal-footer">
                    <button type="button" id="tambahsave" class="btn btn-primary">SIMPAN</button>
                </div>

                <center><p id="notifikasi"></p></center>
            </div>

        </div>
</div>
<!-- ==================================== End modal tambah data =========================================== -->


<!-- ==================================================== Modal edit data ================================== -->
<div class="modal fade" id="editdata" role="dialog">
        <div class="modal-dialog modal-lg" role="document">
            
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">EDIT DATA</h4>
                    <button type="button" class="close" data-dismiss="modal" onclick="document.location.reload();">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="fetched-data"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" id="editsave" class="btn btn-primary">UPDATE</button>
                </div>

                <center><p id="notifikasiedit"></p></center>
            </div>

        </div>
</div>
<!-- ========================================== End modal edit data ====================================== -->


<!-- ===================================== Modal HAPUS data =============================================== -->
<div class="modal fade" id="hapusdata" role="dialog">
        <div class="modal-dialog" role="document">
            
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Konfirmasi</h4>
                </div>
                <div class="modal-body">
                    <div class="fetched-data"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" id="hapus" class="btn btn-primary">Ya</button>
                    <button type="button" class="btn btn-warning" data-dismiss="modal" onclick="document.location.reload();">Tidak</button>
                </div>

                <center><span id="notifikasihapus"></span></center>
            </div>

        </div>
</div>
<!-- ======================================= End modal hapus data ======================================== -->


  <script type="text/javascript">
    $(document).ready(function(){
        // ======================================== TAMBAH DATA =========================================
        $('#tambahdata').on('show.bs.modal', function (e) {              
              $('#tambahsave').click(function() {  
                var kecamatanx  = $('#kecamatan').val();
                var namax       = $('#nama').val();
                var kepaladesax = $('#kepaladesa').val();
                var ibukotax    = $('#ibukota').val();

                //cek data kosong atau tidak
                if(kecamatanx == '' || namax == '' || kepaladesax == '' || ibukotax == ''){
                  alert('Data jangan kosong');
                }else{

                  $.post("modul/desa_tambah.php",
                  {
                    kecamatan: kecamatanx,
                    nama: namax,
                    kepaladesa: kepaladesax,
                    ibukota: ibukotax
                  },
                  function(data,status){
                    //alert("Data: " + data + "\nStatus: " + status);
                    if(data=='Ok'){
                      //alert("Data sudah disimpan");
                      document.getElementById("notifikasi").innerHTML = "<font color='green'>Data telah disimpan</font>";
                      document.location.reload();
                    }else{
                      document.getElementById("notifikasi").innerHTML = "<font color='red'>Gagal, masalah koneksi ke server.</font>";
                    }
                  });
                } //end jika data kosong
              });
        });

        // ==================================== EDIT DATA ============================================
        $('#editdata').on('show.bs.modal', function (e) {
              var rowid = $(e.relatedTarget).data('id');
              //menggunakan fungsi ajax untuk pengambilan data
              $.ajax({
                type : 'GET',
                url : 'modul/desa_edit.php?menu=form',
                data :  'rowid='+ rowid,
                success : function(data){
                $('.fetched-data').html(data);//menampilkan data ke dalam modal
                }
              });

              $('#editsave').click(function() {  
                var id          = $('#id').val();
                var kecamatan   = $('#kecamatanedit').val();
                var nama        = $('#namaedit').val();
                var kepaladesa  = $('#kepaladesaedit').val();
                var ibukota     = $('#ibukotaedit').val();

                $.post("modul/desa_edit.php?menu=save",
                {
                  id: id,
                  kecamatan: kecamatan,
                  nama: nama,
                  kepaladesa: kepaladesa,
                  ibukota: ibukota
                },
                function(data,status){
                  //alert("Data: " + data + "\nStatus: " + status);
                  if(data=='Editok'){
                    //alert("Data sudah disimpan");
                    document.getElementById("notifikasiedit").innerHTML = "<font color='green'>Data telah diubah</font>";
                    document.location.reload();
                  }else{
                    document.getElementById("notifikasiedit").innerHTML = "<font color='red'>Gagal, masalah koneksi ke server.</font>";
                  }
                });
                // alert('Edit sukses');
              });
        });

        // ============================================ HAPUS DATA =======================================
        $('#hapusdata').on('show.bs.modal', function (e) {
              var rowid = $(e.relatedTarget).data('id');
              //menggunakan fungsi ajax untuk pengambilan data
              $.ajax({
                type : 'GET',
                url : 'modul/desa_hapus.php?menu=confirm',
                data :  'rowid='+ rowid,
                success : function(data){
                $('.fetched-data').html(data);//menampilkan data ke dalam modal
                }
              });

              $('#hapus').click(function() {  
                var id= $('#id').val();
                $.post("modul/desa_hapus.php?menu=delete",
                {
                  id: id
                },
                function(data,status){
                  //alert("Data: " + data + "\nStatus: " + status);
                  if(data=='Ok'){
                    //alert("Data sudah disimpan");
                    document.getElementById("notifikasihapus").innerHTML = "<font color='green'>Data telah dihapus</font>";
                    document.location.reload();
                  }else{
                    document.getElementById("notifikasihapus").innerHTML = "<font color='red'>Gagal, masalah koneksi ke server.</font>";
                  }
                });
              });
        });


    });
  </script>
    <script src="js/bootstrapminjs_yed.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
