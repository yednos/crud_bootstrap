<?php
include "../config/koneksi.php";
$id = $_GET['rowid'];

if($_GET['menu']=='confirm'){
  $qq = mysqli_query($con, "SELECT * FROM kecamatan WHERE id_kecamatan='$id'");
  $detail = mysqli_fetch_array($qq);
  echo "<input type='hidden' id='id' class='form-control' value='$detail[id_kecamatan]'>";
  echo "Yakin akan menghapus permanen data <b>$detail[nama_kecamatan]</b> ?";

}else if($_GET['menu']=='delete'){
  mysqli_query($con, "DELETE FROM kecamatan WHERE id_kecamatan='$_POST[id]'");
  echo "Ok";
}
?>