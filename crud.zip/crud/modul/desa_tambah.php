<?php
include "../config/koneksi.php";

$kecamatan     = $_POST['kecamatan'];
$nama          = $_POST['nama'];
$kepaladesa    = $_POST['kepaladesa'];
$ibukota       = $_POST['ibukota'];

$sql = "INSERT INTO desa(id_desa,id_kecamatan,nama_desa,kepala_desa,ibukota_desa)
         VALUES(NULL,'$kecamatan','$nama','$kepaladesa','$ibukota')";
   
   if ($con->query($sql) == TRUE) {
      	echo "Ok";
   }else{
      	echo "Gagal";
   }
   $con->close();
?>