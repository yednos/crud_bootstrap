<?php
include "../config/koneksi.php";
$id = $_GET['rowid'];

if($_GET['menu']=='form'){
  $qq = mysqli_query($con, "SELECT * FROM desa WHERE id_desa='$id'");
  $detail = mysqli_fetch_array($qq);
  echo "<input type='hidden' name='id' id='id' class='form-control' value='$detail[id_desa]'>";
  echo "Kecamatan<select name='kecamatan' id='kecamatanedit' required class='form-control'>";
      $tampil=mysqli_query($con, "SELECT * FROM kecamatan ORDER BY id_kecamatan ASC");
      if ($detail[id_kecamatan]==0){
        echo "<option value='' selected>[pilih kecamatan]</option>";
      } 
      while($w=mysqli_fetch_array($tampil)){
        if ($detail[id_kecamatan]==$w[id_kecamatan]){
          echo "<option value='$w[id_kecamatan]' selected>$w[nama_kecamatan]</option>";
        }else{
           echo "<option value='$w[id_kecamatan]'>$w[nama_kecamatan]</option>";
        }
      }
  echo "</select>";
  echo "Nama desa<input type='text' name='nama' id='namaedit' autofocus class='form-control' value='$detail[nama_desa]'>";
  echo "Kepala desa<input type='text' name='kepaladesa' id='kepaladesaedit' class='form-control' value='$detail[kepala_desa]'>";
  echo "Ibukota<input type='text' name='ibukota' id='ibukotaedit' class='form-control' value='$detail[ibukota_desa]'>";

}else if($_GET['menu']=='save'){
  $sql = "UPDATE desa 
    SET id_kecamatan      ='$_POST[kecamatan]',
      nama_desa           ='$_POST[nama]',
      kepala_desa         ='$_POST[kepaladesa]',
      ibukota_desa        ='$_POST[ibukota]'
    WHERE id_desa         ='$_POST[id]'";
   
   if ($con->query($sql) == TRUE) {
        echo "Editok";
   }else{
        echo "Editgagal";
   }
   $con->close();
}
?>