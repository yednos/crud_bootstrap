<?php
include "../config/koneksi.php";
$id = $_GET['rowid'];

if($_GET['menu']=='form'){
  $qq = mysqli_query($con, "SELECT * FROM kecamatan WHERE id_kecamatan='$id'");
  $detail = mysqli_fetch_array($qq);
  echo "<input type='hidden' id='id' class='form-control' value='$detail[id_kecamatan]'>";
  echo "Nama kecamatan<input type='text' id='namaedit' autofocus class='form-control' value='$detail[nama_kecamatan]'>";
  echo "Nama camat<input type='text' id='camatedit' class='form-control' value='$detail[nama_camat]'>";
  echo "Nama ibukota kecamatan<input type='text' id='ibukotaedit' class='form-control' value='$detail[ibukota_kecamatan]'>";

}else if($_GET['menu']=='save'){
  $sql = "UPDATE kecamatan 
    SET nama_kecamatan='$_POST[nama]',
      nama_camat='$_POST[camat]',
      ibukota_kecamatan='$_POST[ibukota]'
    WHERE id_kecamatan='$_POST[id]'";
   
   if ($con->query($sql) == TRUE) {
        echo "Ok";
   }else{
        echo "Gagal";
   }
   $con->close();
}
?>