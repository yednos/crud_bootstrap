<?php
include "../config/koneksi.php";

$id            = $_POST['id'];
$nama          = $_POST['nama'];
$camat         = $_POST['camat'];
$ibukota       = $_POST['ibukota'];

$sql = "INSERT INTO kecamatan(id_kecamatan,nama_kecamatan,nama_camat,ibukota_kecamatan)
         VALUES(NULL,'$nama','$camat','$ibukota')";
   
   if ($con->query($sql) == TRUE) {
      	echo "Ok";
   }else{
      	echo "Gagal";
   }
   $con->close();
?>