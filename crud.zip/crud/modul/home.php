<!-- 
=============================================================================
+                          SIMPLE CRUD                                      +
+                                                                           +
+                  Dibuat oleh YOHYEDNOS NAKO                               +
+                        www.coneons.com                                    +
+         Dapatkan berbagai source code gratis di website kami.             +
+                Kami juga melayani pembuatan aplikasi                      +
+        silahkan kontak kami lewat email kami yednos@gmail.com             +
+                                                                           +
+                                                                           +
+                                                                           +
+                        WWW.CONEONS.COM                                    +
+                                                                           +
+   Hargai pembuat aplikasi dengan tidak menghapus nama pembuat di footer   +
=============================================================================
-->
<div class="container" style="padding-top: 250px;min-height: 600px;color: blue;">
  <center>
    Selamat datang di APLIKASI CRUD SEDERHANA.</b>
  </center>
</div>
